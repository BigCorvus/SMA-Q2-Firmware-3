#ifndef APP_ERROR_H__
#define APP_ERROR_H__

// normally prints error msg if code not NRF_SUCCESS (i.e. 0)
// this implementation does nothing
#define APP_ERROR_CHECK(code) 
#define APP_ERROR_CHECK_BOOL(code);

#endif // APP_ERROR_H__